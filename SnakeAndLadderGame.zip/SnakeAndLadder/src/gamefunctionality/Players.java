package gamefunctionality;

import java.util.Random;

public class Players extends SnakeLadderGame{
	
	private int diceValue;
	private int playerNumber;
	
	
	public Players(int playerNumber, int diceValue) {
		this.diceValue = diceValue;
		this.playerNumber = playerNumber;
	}
	
	public Players () {}
	
	public int getDiceValue() {
		return diceValue;
	}
	public void setDiceValue(int diceValue) {
		this.diceValue = diceValue;
	}
	public int getPlayerNumber() {
		return playerNumber;
	}
	public void setPlayerNumber(int playerNumber) {
		this.playerNumber = playerNumber;
	}
	
	protected int throwDice(int playerNumber) {
		
		Random random = new Random();
		int diceValue = random.nextInt((AppConstants.MAX_DICE_VALUE - AppConstants.MIN_DICE_VALUE) + 1) + AppConstants.MIN_DICE_VALUE;
		
		return diceValue;
	}
	
	protected int movePlayer (int playerNumber, int currentLocation) {
		
		Players player = new Players();
		int currentLocationTmp = currentLocation;
		int diceValue = player.throwDice(playerNumber);
		System.out.println("Player " + playerNumber + " rolls die scoring " + diceValue);
		currentLocation = currentLocation + diceValue;
		if(currentLocation <= AppConstants.WINNING_BOX_VALUE) {
			if (board[currentLocation-1] != currentLocation) { // ladder or snake present
				currentLocation = board[currentLocation-1];
				
			}
			return currentLocation;
		} else {
			return currentLocationTmp;
		}
		
		
	}
	
	
}
