/**
 * 
 */
package gamefunctionality;

/**
 * @author Rahul Barahpuria
 *
 */
public interface AppConstants {
	
	public int MAX_DICE_VALUE = 6;
	public int MIN_DICE_VALUE = 1;
	public int BOXES = 100;
	public int START_BOX_VALUE = 1;
	public int WINNING_BOX_VALUE = 100;
}
