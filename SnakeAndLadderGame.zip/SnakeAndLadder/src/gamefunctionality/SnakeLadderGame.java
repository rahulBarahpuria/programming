package gamefunctionality;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * @author Rahul Barahpuria
 *
 */
public class SnakeLadderGame {

	static Scanner sc;

	static int board[] = new int[AppConstants.BOXES];

	static Players player = new Players();

	static int[] players;

	// driver method to run the game
	public static void main(String[] args) {

		sc = new Scanner(System.in);
		System.out.println("Enter no. of players");
		int noOfPlayers = sc.nextInt();

		players = new int[noOfPlayers];

		// initialize the game board
		for (int i = 0; i < AppConstants.BOXES; i++) {

			board[i] = i + 1;
		}

		// set ladders
		System.out.println("Press 1 to add ladders or press any integer to exit:");
		int isAddLadder = sc.nextInt();
		;
		while (isAddLadder == 1) {
			addSnakeOrLadder(board);
			System.out.println("Press 1 to add more ladders or press any integer to exit:");
			isAddLadder = sc.nextInt();
		}

		// set snakes
		System.out.println("Press 2 to add snakes or any integer to exit: ");
		int isAddSnake = sc.nextInt();
		while (isAddSnake == 2) {
			addSnakeOrLadder(board);
			System.out.println("Press 2 to add more snakes or any integer to exit: ");
			isAddSnake = sc.nextInt();
		}

		showGameBoard(); // displays the snake and ladder game board
		System.out.println("The game started with " + players.length + " players");
		List<Players> playerPlaySequenceList = doToss(players);
		System.out.println("Player " + playerPlaySequenceList.get(0).getPlayerNumber() + " gets to start.");
		System.out.println();
		startTheGame(playerPlaySequenceList);

	}

	public static void showGameBoard() {

		System.out.println("Game Board : ");
		for (int i = 0; i < board.length; i++) {
			System.out.print(board[i] + ", ");
			if((i+1) % 10 == 0) {
				System.out.println();
			}
		}
		System.out.println();
	}

	public static int[] addSnakeOrLadder(int[] board) {

		System.out.println("Enter source box number: ");
		int src = sc.nextInt();
		System.out.println("Enter destination box number: ");
		int dest = sc.nextInt();
		board[src - 1] = dest;
		return board;
	}

	public static List<Players> doToss(int players[]) {

		int n = players.length;

		List<Players> playerList = new ArrayList<Players>();
		while (n > 0) {
			n--;
			Random random = new Random();
			int tossValue = random.nextInt((AppConstants.MAX_DICE_VALUE - AppConstants.MIN_DICE_VALUE) + 1)
					+ AppConstants.MIN_DICE_VALUE;
			players[n] = tossValue;
			Players player = new Players(n, tossValue);
			System.out.println("Player " + n + " rolls die scoring " + tossValue);
			playerList.add(player);

		}

		Collections.sort(playerList, new Comparator<Players>() {

			@Override
			public int compare(Players player1, Players player2) {

				if (player1.getDiceValue() > player2.getDiceValue()) {
					return -1;
				} else {
					return 1;
				}
			}
		});

		return playerList;
	}

	public static void startTheGame(List<Players> playerPlaySequenceList) {

		Arrays.fill(players, AppConstants.START_BOX_VALUE); // initialize all the players position to the starting box
		boolean isGameEnded = false;
		int totalMovesCount = 0; //counts total number of moves played
		while (!isGameEnded) {
			totalMovesCount++;
			for (Players currentPlayer : playerPlaySequenceList) {

				int currentLocation = player.movePlayer(currentPlayer.getPlayerNumber(),
						players[currentPlayer.getPlayerNumber()]);
				players[currentPlayer.getPlayerNumber()] = currentLocation;
				if (players[currentPlayer.getPlayerNumber()] == AppConstants.WINNING_BOX_VALUE) {
					isGameEnded = true;
					declareWinner(currentPlayer, totalMovesCount);
					break;
				}

			}

			System.out.println("The positions after the sequence of rolls above");
			int playerCount = 0;
			while (playerCount < players.length) {
				System.out.println("player " + playerCount + " - " + players[playerCount]);
				playerCount++;
			}
			System.out.println();
		}

	}

	public static void declareWinner(Players winner, int totalMovesPlayed) {

		System.out.println("Player " + winner.getPlayerNumber() + " has won!!");
		System.out.println("Total moves played = " + totalMovesPlayed);
	}

}
